DRAGON QUEST XI S - ITEMIZATION
Version 1.0 - Windows / Steam XI S build 6291077

INSTALL
1. Extract the entire folder if you received the ZIP.
2. Close Dragon Quest XI S, then double-click Install.cmd.
3. The installer finds your Steam game. If asked, select
   DRAGON QUEST XI S.exe in Game\Binaries\Win64.
4. Start the game using the new "DQXI S - Itemization" Desktop shortcut.
   Wait for "Itemization is ready" before loading an adventure log.

If Windows denies access to the game folder, right-click Install.cmd and
choose Run as administrator. The installer never launches the game itself.

WHAT IS INCLUDED
Regional equipment drops, affixes and rarity colours, Veyl/shard crafting,
salvaging, equipment locks, quality reforging, elemental spell damage,
T1-T24 normal scaling and Class 13-15/T27-T33 upgrades, and all mod artwork.
The forced introductory Tickington trip is bypassed after Hotto.
Kingmaker increases Class by one, up to 15. Its award location has not been
configured yet; this package does not give out test currencies or gear.

SAVES AND UPDATES
The installer never edits adventure logs. Existing installed mod history
is preserved. A previous Itemization Desktop shortcut lets it import your
old runtime's item history automatically on the first installation here.
If you already have modded saves but no old shortcut, use:
  powershell -ExecutionPolicy Bypass -File .\Install.ps1 -ExistingRuntimePath "path to your previous runtime folder"
Never delete the old runtime before the first installation succeeds.
Keep modded adventure logs together with a backup of their item history.

Installed files and history are stored in:
  %LOCALAPPDATA%\DQXI-Itemization\Runtime
Previous mod files/history and an exact restore map are backed up there
under backups each time you install. Other mods are left alone. The known
obsolete Itemization test/currency archives are backed up and disabled.
After installation the downloaded package folder can be moved or removed.

COMPATIBILITY
Requires the supported Windows Steam XI S executable; the installer checks
it before making changes. No Python, development tools or extra runtimes
are needed. The original non-S release and other game builds are unsupported.
Optional 2D mode and Tickington gameplay do not support custom equipment
and can lose it. Stay in 3D with modded logs; only the forced introduction
is bypassed. The bypass does not complete or reward Tickington adventures.

If startup fails, leave the game at its title screen, close it and check
the launcher message. Ensure the full package was extracted before installing.
The installer verifies every package file and rolls back failed changes.
Start with Guides/Player-guide.md for current mechanics and controls.
Guides also contains the current developer guide, modifier catalogue and tier
scaling reference. Licenses accompany the runtime.

DISTRIBUTION CONTENTS
The folder and ZIP exclude personal adventure logs, populated item history,
existing gear/currency state, test requests and grants, debug logs, backups,
extraction folders and local account paths. Fresh-item-history.json is an empty
initialization seed. Keep private saves and their history outside this package.
